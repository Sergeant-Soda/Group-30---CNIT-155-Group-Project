﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_30___CNIT_155_Group_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int cSize = 100;
        private string[] mName = new string[cSize];
        private string[] mPPhone = new string[cSize];
        private string[] mWPhone = new string[cSize];
        private string[] mEMail = new string[cSize];
        private string[] mAffiliation = new string[cSize];
        private int mIndex = 0;

        private void btnEnter_Click(object sender, EventArgs e)
        {

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }
    }
}
